package test;

import java.sql.*;
import java.util.*;
import datos.Conexion;
import datos.IPersonaDAO;
import datos.PersonaDaoJDBC;
import domain.PersonaDTO;

public class TestManejoPersona {

	public static void main(String args[]) {
		
		//Tenemos conexion fuera de personaDao
		Connection conexion = null;
		// la creamos fuera para usarla en todo el codigo
		try {
			conexion =  Conexion.getConnection();
			if(conexion.getAutoCommit()==true) {
				conexion.setAutoCommit(false);
			}
			IPersonaDAO personaDao = new PersonaDaoJDBC(conexion);
	
			List<PersonaDTO>personas = personaDao.select();
			for (PersonaDTO personaDTO : personas) {
				System.out.println("Personas = " + personaDTO);
			}
			
		} catch (SQLException e) {
			e.printStackTrace(System.out);
			System.out.println("Entramos al rollback");
			try {
				conexion.rollback();
			} catch (SQLException e1) {  
				e1.printStackTrace(System.out);
			}// Anque haya un minimo error en una sentencia, se vuelve todo para atras
		}
		
		
		
		
		
	}

}

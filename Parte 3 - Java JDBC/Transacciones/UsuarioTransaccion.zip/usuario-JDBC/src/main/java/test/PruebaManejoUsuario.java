package test;

import java.sql.*;
import java.sql.SQLException;
import java.util.Iterator;
import java.util.List;

import datos.Conexion;
import datos.UsuarioDAO;
import domain.Usuario;

public class PruebaManejoUsuario {

public static void main(String args[]) {
		
		//Tenemos conexion fuera de personaDao
		Connection conexion = null;
		// la creamos fuera para usarla en todo el codigo
		try {
			conexion =  Conexion.getConnection();
			if(conexion.getAutoCommit()==true) {
				conexion.setAutoCommit(false);
			}
			UsuarioDAO personaDao = new UsuarioDAO(conexion);
			Usuario cambioUser = new Usuario(1,"Leonel","54555ddat");
			personaDao.actualizar(cambioUser);
			
			Usuario nuevoUser = new Usuario("Jorgito","4654545ssss");
			personaDao.insertar(nuevoUser);
			
			conexion.commit(); // si esta todo bien, actualiza MySql
			System.out.println("Se ha hecho commit de la transaccion");
			
		} catch (SQLException e) {
			e.printStackTrace(System.out);
			System.out.println("Entramos al rollback");
			try {
				conexion.rollback();
			} catch (SQLException e1) {  
				e1.printStackTrace(System.out);
			}// Anque haya un minimo error en una sentencia, se vuelve todo para atras
		}
		
		
		
		
		
	}

}
